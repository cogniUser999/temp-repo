package mini_project;

import io.github.bonigarcia.wdm.WebDriverManager;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.edge.EdgeDriver;

import java.time.Duration;
import java.util.Scanner;

public class Main {

    /*
    * Case Study: Unregistered user verification
        Problem Statement:
        * Get error message for unregistered user email id
        * Verify error message is displayed for unregistered user
        * Get an error message
        * Suggested site: change2naturalfoods.com, however you are free to choose any other legitimate shopping site.

        Detailed Description:
        * Launch any browser
        * Go to "http://change2naturalfoods.com/
        * Maximize the window
        * Locate Login/Register button
        * Click Login/Register button
        * Enter unregister email id example: jobspari2@gmail.com which is not signed up in this website
        * Enter password example:  “abc258”
        * Click login button
        * Verify error message is displayed for unregistered user
        * Get an error message for unregistered email id and print the same in the console
        * Close browser
    * */

    public static void maxWindow(WebDriver driver) {
        System.out.println("-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-\n---Automation Initiated---");
        driver.manage().window().maximize();
        System.out.println("window size set to max...");
        System.out.println("---------------------------------------------------");
    }

    public static void loginLocator(WebDriver driver) {
        driver.findElement(By.cssSelector("#navbar_0_6 > div.navbar-collapse > ul > li:nth-child(3) > a")).click();
        System.out.println("login/register button located...");
        System.out.println("---------------------------------------------------");
    }

    public static void loginAttempt(WebDriver driver) {
        driver.findElement(By.id("email")).sendKeys("jobspari2@gmail.com");
        System.out.println("Login ID used : \"jobspari2@gmail.com\"");
        driver.findElement(By.id("password")).sendKeys("abc258");
        System.out.println("Login Password used : \"abc258\"");

        // attempt 1...
        driver.findElement(By.cssSelector("body > section > div > div > div:nth-child(1) > div.registration-process > form > div.col-12.col-sm-12 > button")).click();
        System.out.println("login-attempted...");
        System.out.println("---------------------------------------------------");
    }

    public static void main(String[] args) {

        Scanner sc = new Scanner(System.in);
        WebDriver driver = null;
        boolean bool = true;

        do {
            System.out.println("Select the browser you want to use:-");
            System.out.println("1) Google Chrome");
            System.out.println("2) Microsoft Edge");
            System.out.println("Enter the browser you want to use: ");
            int browser = sc.nextInt();
            System.out.println("Automation Script Loading...");
            switch (browser) {
                case 1: {
                    System.out.println("Browser Selected :- Google Chrome");
                    WebDriverManager.chromedriver().setup();
                    driver = new ChromeDriver();
                    bool = false;
                    break;
                }
                case 2: {
                    System.out.println("Browser Selected :- Microsoft Edge");
                    WebDriverManager.edgedriver().setup();
                    driver = new EdgeDriver();
                    bool = false;
                    break;
                }
                default: System.out.println("Enter a valid Web Browser......");
            }

        } while (bool);

        // URL rendering...
        String URL = "https://change2naturalfoods.com/";
        driver.get(URL);

        // implicit wait applied...
        driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(10));

        // maximize current window
        maxWindow(driver);

        // Login/Register button...
        loginLocator(driver);

        // email/password fetch request...
        // login attempted...
        loginAttempt(driver);

        // login failure...
//        String expectedErrorMsg = "×";
        String errorMsg = driver.findElement(By.xpath("/html/body/section/div/div/div[1]/div[1]")).getText();

        System.out.println(errorMsg);


        if (errorMsg != null) {
            System.out.println("---------------------------------------------------");
            System.out.println("user NOT registered with the portal");
            System.out.println("---------------------------------------------------");
        } else {
            System.out.println("---------------------------------------------------");
            System.out.println("user registered with the portal - Login Successful.");
            System.out.println("---------------------------------------------------");
        }

        driver.quit();
    }
}