package pageObjects.TravelInsurance;

import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.ExpectedConditions;
import testBase.baseClass;

/*
 *   project
 *       |-> test
 *              |-> pageObjects package
 *                      |-> Travel Insurance
 *                                  |-> tripDates.java
 *
 *   Description : ▫️Locating elements on calendar page to update the travel dates
 *                 ▫️handling date inputBox to select start date and end date for travelling and plan search
 * */


public class tripDatesPageTravel extends baseClass {

    public tripDatesPageTravel(){
        PageFactory.initElements(driver, this);
    }
    /* #Locators */
//    @FindBy(xpath = "//input[@class=\"MuiInputBase-input MuiOutlinedInput-input\"]")
    @FindBy(xpath = "//*[@id=\"prequote-wrapper\"]/div[2]/div/div[1]/div/div[1]/div/div/input")
    WebElement dateBox;

    @FindBy(xpath = "//button[@class=\"MuiButtonBase-root MuiPickersDay-root MuiPickersDateRangeDay-day MuiPickersDateRangeDay-notSelectedDate MuiPickersDateRangeDay-dayOutsideRangeInterval MuiPickersDay-today\"]")
    WebElement startDate;
    @FindBy(css = "body > div.MuiPickersPopper-root > div.MuiPaper-root.MuiPickersPopper-paper.MuiPickersPopper-topTransition.MuiPaper-elevation8.MuiPaper-rounded > div > div > div:nth-child(2) > div.MuiPickersSlideTransition-root.MuiPickersCalendar-root.MuiPickersDesktopDateRangeCalendar-calendar > div > div:nth-child(4) > div:nth-child(4) > div > button")
    WebElement endDate;

    @FindBy(xpath = "//*[@id=\"prequote-wrapper\"]/div[2]/div/p")
    WebElement tripDuration;

    @FindBy(xpath = "//button[@class=\"travel_main_cta\"]")
    WebElement proceedToTravellers;

    /* #Functions */
    public void dateSelectFunction() throws InterruptedException {
        wait.until(ExpectedConditions.visibilityOf(dateBox));
        Thread.sleep(3000);
        dateBox.click();
        wait.until(ExpectedConditions.visibilityOf(startDate));
        Thread.sleep(1000);
        startDate.click();
        wait.until(ExpectedConditions.visibilityOf(endDate));
        Thread.sleep(1000);
        endDate.click();
        System.out.println(tripDuration.getText());
        wait.until(ExpectedConditions.visibilityOf(proceedToTravellers));
        Thread.sleep(1000);
        proceedToTravellers.click();
    }
}
