package pageObjects.TravelInsurance;

import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.ExpectedConditions;
import testBase.baseClass;

import java.util.List;

/*
 *   project
 *       |-> test
 *              |-> pageObjects package
 *                      |-> Travel Insurance
 *                                  |-> travellersPage.java
 *
 *   Description : ▫️Locating elements on travellers page to select travellers on the page with age selection
 *                 ▫️handling the dropdowns for each traveller for age selection
 *                 ▫️proceeding to next page for plans search - proceedToMedPage()
 * */

public class travellersPageTravel extends baseClass {

    public travellersPageTravel(){
        PageFactory.initElements(driver, this);
    }

    /* #Locators */
    @FindBy(xpath = "//div[@class=\"memSelectRadioWrapper__radio\"][2]//label")
    WebElement numberOfTravellers;

    @FindBy(xpath = "//div[@id=\"0\"]//div[@class=\"place-holder AgeSelector-place-holder\"]")
    WebElement drop1;
    @FindBy(xpath = "//div[@class=\"inputSelectList__window\"]//label")
    List<WebElement> dropdownT1;

    @FindBy(xpath = "//div[@id=\"1\"]//div[@class=\"place-holder AgeSelector-place-holder\"]")
    WebElement drop2;
    @FindBy(xpath = "//div[@class=\"inputSelectList__window\"]//label")
    List<WebElement> dropdownT2;

    @FindBy(xpath = "//button[@class=\"travel_main_cta\"]")
    WebElement proceed;

    /* #Functions */
    public void totalTravellers() throws InterruptedException {
        wait.until(ExpectedConditions.visibilityOf(numberOfTravellers));
        numberOfTravellers.click();
    }

    public void traveller1Selection() throws InterruptedException {
        wait.until(ExpectedConditions.visibilityOf(drop1));
        drop1.click();
        for(WebElement age : dropdownT1){
            if(age.getText().equals("21 years")){
                age.click();
                break;
            }
        }
    }
    public void traveller2Selection(){
        wait.until(ExpectedConditions.visibilityOf(drop2));
        drop2.click();
        for(WebElement age : dropdownT2){
            if(age.getText().equals("22 years")){
                age.click();
                break;
            }
        }
    }

    public void proceedToMedPage(){
        wait.until(ExpectedConditions.visibilityOf(proceed));
        proceed.click();
    }
}
