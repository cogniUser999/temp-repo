package pageObjects.CarInsurance;

import actionPackage.actionClass;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Action;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import testBase.baseClass;

public class homePageCar extends baseClass {
    public homePageCar(){
        PageFactory.initElements(driver, this);
    }
    actionClass action = new actionClass();

    /* #Locators */
    @FindBy(xpath="//a[contains(text(),'Insurance Products')]")
    private WebElement insuranceProducts;
    @FindBy(xpath="//a[@class=\"headlink\" and contains(text(),\"Car Insurance\")]")
    private WebElement carInsuranceEle;
    @FindBy(xpath="//*[contains(@class,'input_box')]//input")
    public WebElement searchCarNumber;
    @FindBy(xpath="//*[@id=\"btnSubmit\"]")
    public WebElement viewPriceBtn;
    @FindBy(xpath="//div[@class='err' and contains(text(),'Please enter')]")
    public WebElement errmsg;
    @FindBy(xpath="//input[@id=\"txtName\"]")
    public WebElement inputUserName;
    @FindBy(xpath="//input[@id=\"txtEmail\"]")
    public WebElement inputEmail;
    @FindBy(xpath="//input[@id=\"mobNumber\"]")
    public WebElement inputPhNumber;
    @FindBy(xpath="//div[normalize-space()='View Prices']")
    public WebElement viewPrices;
    @FindBy(xpath="//p[text()=\"No\"]")
    public WebElement NoPlans;

    /* #Functions */
    public void visitCarInsurance() {
//        driver.get("https://www.policybazaar.com/");
        action.hoverOnElement(driver, insuranceProducts);
        carInsuranceEle.click();
    }
    public void validateCarInsurance() {
        action.navigateToPage(driver, NoPlans);
//		Assert.assertEquals(driver.getTitle(), "Car Insurance");
//		if(driver.getTitle().equals("Car Insurance")) {
//			System.out.println("Validation Successfully Done");
    }

}
