package pageObjects.CarInsurance;

import org.apache.commons.math3.analysis.function.Exp;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.ExpectedConditions;
import reportManager.extentReportManager;
import testBase.baseClass;
import utilsPackage.utils;

public class userPageCar extends baseClass {
    //    extentReportManager ExtentReportManager = new extentReportManager();
    utils utility = new utils();

    public userPageCar() {
        PageFactory.initElements(driver, this);
    }

    /* #Locators */
    @FindBy(xpath = "//div[@class='err' and contains(text(),'Please enter')]")
    public WebElement errorMessage;
    @FindBy(xpath = "//input[@id=\"txtName\"]")
    WebElement inputUserName;
    @FindBy(xpath = "//input[@id=\"txtEmail\"]")
    WebElement inputEmail;
    @FindBy(xpath = "//input[@id=\"mobNumber\"]")
    WebElement inputPhoneNumber;
    @FindBy(xpath = "//div[@class=\"button btnOrange\"]//span")
    WebElement viewPrices;
    @FindBy(xpath = "//p[text()=\"No\"]")
    WebElement NoPlans;


    /* #Functions */
    public boolean getErrorMessage() {
        Actions action = new Actions(driver);
        action.keyDown(Keys.ENTER).perform();
        try {
            if (errorMessage.isDisplayed()) {
                extentReportManager.errorMessage = true;
                return true;
            } else {
                extentReportManager.errorMessage = false;
                return false;
            }
        } catch (Exception ignored) {
        }
        extentReportManager.errorMessage = false;
        return false;
    }

    public void fillApplicationDetails(String name, String email, String number) {
        inputUserName.clear();
        inputUserName.sendKeys(name);

        inputEmail.clear();
        inputEmail.sendKeys(email);

        inputPhoneNumber.clear();
        inputPhoneNumber.sendKeys(number);

        new Actions(driver).keyDown(Keys.ENTER).perform();
    }

    public void nextPage() throws InterruptedException {
        wait.until(ExpectedConditions.visibilityOf(viewPrices));
        viewPrices.click();
        Thread.sleep(2000);
    }
}
