package pageObjects.CarInsurance;

import org.openqa.selenium.Keys;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import reportManager.extentReportManager;
import testBase.baseClass;
import utilsPackage.utils;

public class numberPageCar extends baseClass {
    utils utility = new utils();
//    extentReportManager ExtentReportManager = new extentReportManager();
    public numberPageCar(){
        PageFactory.initElements(driver, this);
    }

    /* #Locators */
    @FindBy(xpath="//*[contains(@class,'input_box')]//input")
    WebElement searchCarNumber;
    @FindBy(xpath="//*[@id=\"btnSubmit\"]")
    public WebElement viewPriceBtn;

    @FindBy(xpath="//div[@class='err' and contains(text(),'Please enter')]")
    public WebElement errorMessage;

    /* #Functions */
    public boolean getErrorMessage(){
        Actions action = new Actions(driver);
        action.keyDown(Keys.ENTER).perform();
        try {
            if(errorMessage.isDisplayed()){
                extentReportManager.errorMessage = true;
                return true;
            }
            else{
                extentReportManager.errorMessage = false;
                return false;
            }
        }
        catch(Exception ignored){
        }
        extentReportManager.errorMessage = false;
        return false;
    }
    public void clear(){
        searchCarNumber.clear();
    }

    public String getData(String filedValue) {
        String dataFile = "carInsuranceData";
        String[] testData = utility.parseTestData(dataFile, filedValue);
        return utility.getRandomData(testData);
    }

    public String[] getAllData(String filedValue) {
        String dataFile = "carInsuranceData";
        return utility.parseTestData(dataFile, filedValue);
    }
    public void submitCarNumber(String carNumber){
        searchCarNumber.clear();
        searchCarNumber.sendKeys(carNumber);
    }

//    public void searchHelper(String number){
//        searchCarNumber.sendKeys(number);
//    }

//    public void viewPrice(){
//        viewPriceBtn.click();
//    }
}
