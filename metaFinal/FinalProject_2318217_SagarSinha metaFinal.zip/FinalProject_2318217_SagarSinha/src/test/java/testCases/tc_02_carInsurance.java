package testCases;

import org.openqa.selenium.Keys;
import org.openqa.selenium.interactions.Actions;
import org.testng.Assert;
import org.testng.annotations.AfterClass;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;
import pageObjects.CarInsurance.insurancePlansPageCar;
import pageObjects.CarInsurance.numberPageCar;
import pageObjects.CarInsurance.homePageCar;
import pageObjects.CarInsurance.userPageCar;
import testBase.baseClass;

import java.util.HashSet;
import java.util.Set;

public class tc_02_carInsurance extends baseClass {
    private Set<String> errorDataSet = new HashSet<>();
    /* #Page Objects */
    homePageCar home = new homePageCar();
    numberPageCar carPage = new numberPageCar();
    userPageCar user = new userPageCar();
    insurancePlansPageCar plan = new insurancePlansPageCar();

    @BeforeClass
    public void objCreation() {
        home = new homePageCar();
        carPage = new numberPageCar();
        user = new userPageCar();
        plan = new insurancePlansPageCar();
    }

    /* #Test Methods */
    @Test(priority = 0)
    public void renderingURL(){
        navigateToURL();
    }

    // test -
    @Test(priority = 1)
    public void navigateToCarInsurancePage() {
        home.visitCarInsurance();
    }


    // test - search (No Number Data)
    @Test(priority = 2, dependsOnMethods = "navigateToCarInsurancePage")
    public void searchWithoutCarNumber(){
        carPage.submitCarNumber("");
        boolean status = carPage.getErrorMessage();
        Assert.assertTrue(status);
    }

    // test - search (Invalid Number Data)
    @Test(priority = 3, dependsOnMethods = "searchWithoutCarNumber")
    public void searchWithInvalidCarNumber(){
        String carNumber = carPage.getData("InvalidCarNumber");
        carPage.submitCarNumber(carNumber);
        boolean status = carPage.getErrorMessage();
        Assert.assertTrue(status);
    }

    // test - search (Valid Number Data)
    @Test(priority = 4, dependsOnMethods = "searchWithInvalidCarNumber")
    public void searchWithValidCarNumber(){
        String carNumber = carPage.getData("ValidCarNumber");
        carPage.submitCarNumber(carNumber);
        boolean status = carPage.getErrorMessage();
        Assert.assertFalse(status);
    }

    // test - search (No Data)
    @Test(priority = 5, dependsOnMethods = "searchWithValidCarNumber")
    public void searchWithoutUserDetails(){
        user.fillApplicationDetails("","","");
        boolean status = carPage.getErrorMessage();
        Assert.assertTrue(status);
    }

    // test - search (Invalid Name Data)
    @Test(priority = 6, dependsOnMethods = "searchWithoutUserDetails")
    public void searchWithInvalidName(){
        String[] formData = carPage.getAllData("InvalidName");
        user.fillApplicationDetails(formData[0],formData[1],formData[2]);
        boolean status = carPage.getErrorMessage();
        Assert.assertTrue(status);
    }

    // test - search (Invalid Email Data)
    @Test(priority = 7, dependsOnMethods = "searchWithInvalidName")
    public void searchWithInvalidEmail(){
        String[] formData = carPage.getAllData("InvalidEmail");
        user.fillApplicationDetails(formData[0],formData[1],formData[2]);
        boolean status = carPage.getErrorMessage();
        Assert.assertTrue(status);
    }

    // test - search (Invalid Number Data)
    @Test(priority = 8, dependsOnMethods = "searchWithInvalidEmail")
    public void searchWithInvalidNumber(){
        String[] formData = carPage.getAllData("InvalidNumber");
        user.fillApplicationDetails(formData[0],formData[1],formData[2]);
        boolean status = carPage.getErrorMessage();
        Assert.assertTrue(status);
    }

    // test - title assertion for last page
//    @Test(priority = 9, dependsOnMethods = "searchWithInvalidNumber")
//    public void validRedirecting() throws InterruptedException {
//        user.nextPage();
//        plan.titleAssertion();
//    }

    // test - navigating back to home page
    @Test(priority = 10, dependsOnMethods = "searchWithInvalidNumber")
    public void navigateBackToHomePage(){
        navigateToHome();
    }
}
