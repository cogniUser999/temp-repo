
# Find travel insurance plan for students

## Problem Statement

The challenge is to find suitable travel insurance plans for student travelers,
specifically targeting a group of two individuals aged 22 and 21,
intending to visit any European country. The goal is to identify the lowest international travel insurance plans, including their respective amounts and insurance provider companies.


## Details

1. Find travel insurance plan for students, for 2 people (Age 22 & 21) & any European country, fill further dummy details & display the lowest international travel insurance plan with amount and insurance provider company

2. Get a Car Insurance quote, proceed without car number, keep filling details, give invalid email or phone number & capture the error message

3. Retrieve all Health Insurance menu items and store in a List; Display the same.

(Suggested Site: policybazaar.com however you are free to use any other legitimate site)

## Features
1. **Automation with Selenium and Java:** This project leverages Selenium to in test scripts to automate PolicyBazaar.
2. **Page Object Model (POM) Design Pattern:** Implemented the POM design pattern using PageFactory to enhance test maintainability by separating page elements from test logic. Each web page has its corresponding Page Object class, making it easier to manage and update test cases.
3. **Data-Driven Testing:** We’ve incorporated data-driven testing by reading test data from JSON files allowing us to parameterize test and execute them with different input data.
4. **TestNG for Test Suite Creation**: Implemented TestNG to organize test cases into different test suites enabling us to define dependencies, perform parallel execution, and other configurations using TestNG annotations.
5. **Multi-Browser Testing Support:** Our test suite supports multiple browsers, including Google Chrome and Microsoft Edge to ensure cross-browser compatibility.
6. **Extent Report Generation:**
   After each test execution, Extent Report is generated with embedded screenshots in report for visual validation.
7. **Maven Integration:** We’ve integrated Maven to handles dependencies easily.

## Technologies Used

1. Selenium
2. TestNG with POM approach
3. ExtentReports


# Directory Structure
[//]: # (* [.idea]&#40;./tree-md&#41;)

[//]: # (* [dir2]&#40;./dir2&#41;)

[//]: # (   * [file21.ext]&#40;./dir2/file21.ext&#41;)

[//]: # (   * [file22.ext]&#40;./dir2/file22.ext&#41;)

[//]: # (   * [file23.ext]&#40;./dir2/file23.ext&#41;)

[//]: # (* [dir1]&#40;./dir1&#41;)

[//]: # (   * [file11.ext]&#40;./dir1/file11.ext&#41;)

[//]: # (   * [file12.ext]&#40;./dir1/file12.ext&#41;)

[//]: # (* [file_in_root.ext]&#40;./file_in_root.ext&#41;)

[//]: # (* [README.md]&#40;./README.md&#41;)

[//]: # (* [dir3]&#40;./dir3&#41;)


<pre>
Final Project
├── src
      └── test
            ├── java
                  ├── actionPackage
                        └── actionClass
                  ├── pageObjects
                        ├── TravelInsurance
                        ├── CarInsurance
                        └──HealthInsurance
                  ├── reportManager
                        └── ExtentReportManager
                  ├── testBase
                        └── baseClass
                  ├── testCases
                        ├── tc_01_travel
                        ├── tc_02_car
                        └──tc_03_health
                  ├── utilsPackage
                        └──utils
            └── resources (test resource root)
                  ├── testData
                        └── carInsurance.json
                  └── testSuites
                        ├── chromeSuite.xml
                        └── edgeSuite.xml
├── target (auto)
├── testOutput
      ├── Screenshots
      └── testReports
├── engine.xml
├── pom.xml
├── README.md
└── External Libraries
    ├── Maven.com.google (external)
    └── <17>Azul zulu jdk
</pre>
